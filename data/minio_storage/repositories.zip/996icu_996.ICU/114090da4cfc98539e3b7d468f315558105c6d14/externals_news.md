# 相关媒体报道，感谢媒体朋友们

## 中文媒体

- 新浪财经：[多名政协委员回应马云996：对员工提要求就是违法](http://finance.sina.com.cn/chanjing/gsnews/2019-04-18/doc-ihvhiqax3657558.shtml)

- 新浪财经：[胡锡进谈“996”现象：既莫上纲上线 也应认真缓解](http://finance.sina.com.cn/wm/2019-04-06/doc-ihvhiqax0439519.shtml?cre=tianyi&mod=pchp&loc=1&r=0&rfunc=100&tj=none&tr=12)

- 新浪资讯：[沉默or抵制? 多家互联网公司被指实行996工作制](https://zx.sina.cn/2019-04-06/zx-ihvhiqax0377991.d.html)（[Wayback Machine](https://web.archive.org/web/20190409024013/https://zx.sina.cn/2019-04-06/zx-ihvhiqax0377991.d.html)）

- 每日经济网：[“996”不符合社会主义关于人的发展价值观](http://www.nbd.com.cn/articles/2019-04-14/1321040.html)

- 经济日报：[挥别“996”，从今天开始](http://paper.ce.cn/jjrb/html/2019-04/18/content_389134.htm)

- 经济日报： [互联网“996工作制”遭诟病](http://paper.ce.cn/jjrb/html/2019-04/11/content_388567.htm)

- 经济日报（中国经济网）：[拒绝“996”工作制！以人为本才能获得长远发展](http://views.ce.cn/view/ent/201904/03/t20190403_31794131.shtml)（[Wayback Machine](https://web.archive.org/web/20190409022740/http://views.ce.cn/view/ent/201904/03/t20190403_31794131.shtml)）

- 中国经济网：[“996”工作制有蔓延趋势：超七成白领无偿加班](http://www.ce.cn/cysc/newmain/yc/jsxw/201904/22/t20190422_31908001.shtml)

- 人民网：[遏制“996” 需要劳动监察部门发力](http://industry.people.com.cn/n1/2019/0417/c413883-31033624.html)

- 人民网：[“996工作制”是谁的如意算盘？](http://opinion.people.com.cn/n1/2019/0402/c119388-31009768.html)（[Wayback Machine](https://web.archive.org/web/20190409022535/http://opinion.people.com.cn/n1/2019/0402/c119388-31009768.html)）

- 中新网：[逃离996：我宁可不婚不育不买房，也不要拼命](http://www.chinanews.com/gn/2019/04-16/8809887.shtml)

- 新华网：[辛识平：奋斗应提倡，996当退场](http://www.xinhuanet.com/politics/2019-04/15/c_1124370790.htm)

- 半月谈：[半月谈三评996：违法、过劳、伪奋斗](http://www.banyuetan.org/pl/detail/20190416/1000200033136001555374820326895304_1.html)

- 半月谈：[半月谈评论：996与奋斗无关，与利益有关](http://www.banyuetan.org/dyp/detail/20190415/1000200033134991555306789054254821_1.html)

- 半月谈： [半月谈评论：警惕常态化的“996”工作制催生“过劳一代”](http://www.banyuetan.org/jrt/detail/20190412/1000200033134991555033104055857336_1.html)

- 人民日报： [崇尚奋斗，不等于强制996](https://m.weibo.cn/status/4360947026232430)

- 人民日报： [人民日报评论：不能给反对996的员工贴“混日子”标签](https://finance.ifeng.com/c/7lrctvSXirY)

- 人民日报： [工作996生病ICU，劳动监察部门应积极介入](https://m.weibo.cn/status/4357697258275940)

- 人民日报： [强制加班不应成为企业文化](http://paper.people.com.cn/rmrb/html/2019-04/11/nw.D110000renmrb_20190411_2-19.htm)

- 光明网： [莫让“996工作制”成了职场明规则](http://guancha.gmw.cn/2019-04/06/content_32719988.htm)（[Wayback Machine](https://web.archive.org/web/20190409022532/http://guancha.gmw.cn/2019-04/06/content_32719988.htm)）

- 工人日报：[马云谈996时，可曾知道8小时工作制是这样争取来的！](https://mp.weixin.qq.com/s/tp0u0wI0gHEjlV5ZpdDoDQ)

- 工人日报：[“工作996，生病ICU”该引起重视了](http://news.workercn.cn/32845/201904/07/190407041525409.shtml)（[Wayback Machine](https://web.archive.org/web/20190409022551/http://news.workercn.cn/32845/201904/07/190407041525409.shtml)）

- 央广网：[风波再起 40余家互联网公司被指实行“996工作制”](http://china.cnr.cn/xwwgf/20190405/t20190405_524568985.shtml)（[Wayback Machine](https://web.archive.org/web/20190409022701/http://china.cnr.cn/xwwgf/20190405/t20190405_524568985.shtml)）

- 中工网：[“996”工作制，道德绑架无法掩盖违法事实](http://right.workercn.cn/164/201904/08/190408094926754.shtml)（[Wayback Machine](https://web.archive.org/web/20190409022600/http://right.workercn.cn/164/201904/08/190408094926754.shtml)）

- 南方日报：[正视年轻人压力“爆棚”的危险](http://epaper.southcn.com/nfdaily/html/2019-04/03/content_7790850.htm)（[Wayback Machine](https://web.archive.org/web/20190409022702/http://epaper.southcn.com/nfdaily/html/2019-04/03/content_7790850.htm)）

- 广州日报：[“996工作制”不可持续](http://gzdaily.dayoo.com/pc/html/2019-04/03/content_108225_594534.htm)（[Wayback Machine](https://web.archive.org/web/20190409022702/http://gzdaily.dayoo.com/pc/html/2019-04/03/content_108225_594534.htm)）

- 全天候科技：[996，谁的ICU？](https://awtmt.com/articles/3506048)（[Wayback Machine](https://web.archive.org/web/20190409022752/https://awtmt.com/articles/3506048)）

- 差评：[奥斯维辛没有新闻，互联网也没有什么996。](https://mp.weixin.qq.com/s/ML_VnsWcQdUGCLYXOABlrw)（[Wayback Machine](https://web.archive.org/web/20190409022803/https://mp.weixin.qq.com/s/ML_VnsWcQdUGCLYXOABlrw)）

- 好奇心日报：[在代码仓库里反对“996”，中国程序员抗议加班制度](https://www.qdaily.com/articles/62583.html)（[Wayback Machine](https://web.archive.org/web/20190405021913/https://www.qdaily.com/articles/62583.html)）

- 好奇心日报：[~~996 惹怒程序员之后，他们的抗议引发了全球关注~~](https://www.qdaily.com/articles/62652.html)（[Wayback Machine](https://web.archive.org/web/20190405013618/https://www.qdaily.com/articles/62652.html)）

- 中国青年报：[被“996”工作制围困的年轻人：像是定好闹钟的机器](http://zqb.cyol.com/html/2019-04/02/nw.D110000zgqnb_20190402_1-02.htm)

- 北京青年报：[40家互联网公司陷“996”工作制风波](http://www.chinanews.com/sh/2019/04-05/8801021.shtml)（[Wayback Machine](https://web.archive.org/web/20190409023804/http://www.chinanews.com/sh/2019/04-05/8801021.shtml)）

- 深圳卫视：[滚蛋吧，“996”式加班！](https://www.toutiao.com/a6675967261229974023)（[Wayback Machine](https://web.archive.org/web/20190409023805/https://www.toutiao.com/a6675967261229974023)）

- 电子工程专辑：[工作996，生病ICU](https://www.eet-china.com/news/201904011154.html)（[Wayback Machine](https://web.archive.org/web/20190409023824/https://www.eet-china.com/news/201904011154.html)）

- PCM：[【日日做到冇停手】國內程式員透過 Github 抗議 996 加班文化](https://www.pcmarket.com.hk/2019/04/03/%E5%9C%8B%E5%85%A7%E7%A8%8B%E5%BC%8F%E5%93%A1%E9%80%8F%E9%81%8Egithub%E6%8A%97%E8%AD%B0996%E5%8A%A0%E7%8F%AD%E6%96%87%E5%8C%96/)（[Wayback Machine](https://web.archive.org/web/20190405045935/https://www.pcmarket.com.hk/2019/04/03/%E5%9C%8B%E5%85%A7%E7%A8%8B%E5%BC%8F%E5%93%A1%E9%80%8F%E9%81%8Egithub%E6%8A%97%E8%AD%B0996%E5%8A%A0%E7%8F%AD%E6%96%87%E5%8C%96/)）

- 端传媒：[朝九晚九每週六天：大陸程序員GitHub上抗議996血汗加班，能否凱旋歸來？](https://theinitium.com/roundtable/20190404-roundtable-zh-996icu/)

- 联合新闻网：[工程師大串連！在github上用程式碼抗議996血汗加班制](https://udn.com/news/story/7086/3728572)（[Wayback Machine](https://web.archive.org/web/20190331140919/https://udn.com/news/story/7086/3728572)）

- 观察者：[程序员们揭露“996ICU” 互联网公司：华为阿里等上榜](https://www.guancha.cn/politics/2019_04_05_496491_s.shtml)（[Wayback Machine](https://web.archive.org/web/20190409023825/https://www.guancha.cn/politics/2019_04_05_496491_s.shtml)）

- 21财经：[工作996，生病ICU！程序员们这次忍不了了，弄出个大项目](https://m.21jingji.com/article/20190404/herald/23b634af7003164f1ca6f602772a5c71.html)（[Wayback Machine](https://web.archive.org/web/20190409023828/https://m.21jingji.com/article/20190404/herald/23b634af7003164f1ca6f602772a5c71.html)）

- 爱范儿：[病态的 996 早需改变，而且不应该只从程序员开始](https://mp.weixin.qq.com/s/4YVDRAHl3E4AF163xhDKjA)（[Wayback Machine](https://web.archive.org/web/20190406123533/https://mp.weixin.qq.com/s/4YVDRAHl3E4AF163xhDKjA)）

- 都市快报：[平时996，生病ICU！杭州90后小伙昨晚晕倒在之江大桥上，同事说他天天加班](https://www.sohu.com/a/307906125_671633)

- 36氪: [996 到底还要不要继续？](https://mp.weixin.qq.com/s/8opnRvTaiwkUWBBuIhhM8Q)（[Wayback Machine](https://web.archive.org/web/20190409024017/https://mp.weixin.qq.com/s/8opnRvTaiwkUWBBuIhhM8Q)）

- 爱否科技: [继续沉默？996 的「罪与罚」](https://mp.weixin.qq.com/s/wejz1ty8_NoMTrmE5uIZoQ)（[Wayback Machine](https://web.archive.org/web/20190409024017/https://mp.weixin.qq.com/s/wejz1ty8_NoMTrmE5uIZoQ)）

- 电脑报: [“996”成互联网公司行规： 我们为何要没完没了的加班？](https://weibo.com/cpcw?profile_ftype=1&is_hot=1#_0)

- 新民晚报：[不能任由企业“996”](http://xmwb.xinmin.cn/html/2019-04/08/content_5_4.htm)（[Wayback Machine](https://web.archive.org/web/20190409024018/http://xmwb.xinmin.cn/html/2019-04/08/content_5_4.htm)）

- 人民政协网：[“996制”遭抵制 加班文化需重新审视](http://www.rmzxb.com.cn/c/2019-04-08/2325218.shtml)（[Wayback Machine](https://web.archive.org/web/20190409024018/http://www.rmzxb.com.cn/c/2019-04-08/2325218.shtml)）

- 红网[湖南省党网]：[“996加班文化”实为“吸血文化”](https://moment.rednet.cn/content/2019/04/07/5303831.html)（[Wayback Machine](https://web.archive.org/web/20190409024018/https://moment.rednet.cn/content/2019/04/07/5303831.html)）

- 澎湃新闻：[996是天然正确的工作伦理？其实延长工时并不能提高生产力](https://www.thepaper.cn/newsDetail_forward_3272320)（[Wayback Machine](https://web.archive.org/web/20190409024018/https://www.thepaper.cn/newsDetail_forward_3272320)）

- 齐鲁晚报：[互联网行业成“996工作制”重灾区](http://epaper.qlwb.com.cn/qlwb/content/20190407/ArticelA04002FM.htm) ([Wayback Machine](https://web.archive.org/web/20190412051636/http://epaper.qlwb.com.cn/qlwb/content/20190407/ArticelA04002FM.htm))

- 深圳特区报：[996工作制”：竭泽而渔不可取](http://sztqb.sznews.com/PC/layout/201904/08/node_A02.html#content_630258)

- 海外网：[抵制“996”折射中国社会一大发展变化](http://opinion.haiwainet.cn/n/2019/0409/c353596-31532645.html) ([Wayback Machine](https://web.archive.org/web/20190412051759/http://opinion.haiwainet.cn/n/2019/0409/c353596-31532645.html))

- 搜狐新闻：[想要拯救中国程序员，「Python 之父」也看不下去 996 了](https://www.sohu.com/a/306720983_105527) ([Wayback Machine](https://web.archive.org/web/20190412051812/https://www.sohu.com/a/306720983_105527))

- 央视网: [工作996、生病ICU，高薪工作为何总难摆脱加班命运？](https://mp.weixin.qq.com/s/PCtiuFlAPEmJqHr7rRmkww) ([Wayback Machine](https://web.archive.org/web/20190412051815/https://mp.weixin.qq.com/s/PCtiuFlAPEmJqHr7rRmkww))

- 央视新闻：[“工作996，生病ICU” 你遭遇过这样的加班吗？](http://m.news.cctv.com/2019/04/09/ARTIsThYaww3YyEsiirdc0Jt190409.shtml) ([Wayback Machine](https://web.archive.org/web/20190412051813/http://m.news.cctv.com/2019/04/09/ARTIsThYaww3YyEsiirdc0Jt190409.shtml))

- InfoQ：[996.ICU 背后：程序员在互联网公司的真实生态](https://www.infoq.cn/article/0iTzgfWTY8-ehJV5JoTO)

- IT之家：[“Python之父发声：我们能为中国的“996”程序员做什么？](https://www.ithome.com/0/418/079.htm) ([Wayback Machine](https://web.archive.org/web/20190412051817/https://www.ithome.com/0/418/079.htm))

- 南方都市报：[“996”不止互联网，学者建议增加工时，低标准、严执法](https://m.mp.oeeee.com/a/BAAFRD000020190409151093.html) ([Wayback Machine](https://web.archive.org/web/20190412051817/https://m.mp.oeeee.com/a/BAAFRD000020190409151093.html))

- 东方卫报：[“996”工作制当以高压监管扭转高压加班](http://dfwb.njnews.cn/html/2019-04/10/content_63529.htm) ([Wayback Machine](https://web.archive.org/web/20190412052515/http://dfwb.njnews.cn/html/2019-04/10/content_63529.htm))

- 四川日报：[“工作996，生病ICU”上热搜 ，你的工作加班严重吗？](https://mp.weixin.qq.com/s/jkmRgTicyZyC604kIJhn-g)([Wayback Machine](https://web.archive.org/web/20190410031555/https://mp.weixin.qq.com/s/jkmRgTicyZyC604kIJhn-g))

- 钱江晚报：[“996”工作制，道德绑架无法掩盖违法事实](http://qjwb.zjol.com.cn/html/2019-04/08/content_3757863.htm?div=-1)

- 凤凰网：[视频：监控实拍深圳某公司程序员周末加班突然晕倒 现场画面触目惊心](http://v.ifeng.com/video_22036450.shtml)

- 凤凰网：[胡锡进三谈996：高管有想怎么工作都行的选择权，但员工却没有](http://v.ifeng.com/201904/video_38353481.shtml)

- 凤凰网：[拒绝996同样是为了中国经济！新华社、人民日报等官媒：996当退场](https://feng.ifeng.com/c/7m379HCXbMq)

- 环球网：[胡锡进再谈996:公司高管怎么高强度工作都行,但不应强制要求员工](https://m.huanqiu.com/r/MV8wXzE0NzE3MTY1XzEyNjRfMTU1NTEzODkyMA==)

- 金融界：[冯仑：关于「996」，我的看法是这样的](https://baijiahao.baidu.com/s?id=1631468784393271629&wfr=spider&for=pc)


### 非中国媒体

- BBC中文网：[中国程序员GitHub上抗议“996”血汗加班走红网络](https://www.bbc.com/zhongwen/simp/chinese-news-47824716)

- 美国之音：[中国科技工作者在线抗议“996”工作制](https://www.voachinese.com/a/china-tech-labor-996-20190404/4862315.html)

- 多维新闻网：[“码农”线上串联维权 引中国官媒关注](http://news.dwnews.com/china/news/2019-04-03/60127095.html)

- 联合早报：[中国程序员网上抗议“996”工作制引关注](https://www.zaobao.com/realtime/china/story20190405-946187)
- 联合早报：[胡锡进：996不能够成为职场普遍号召](https://www.zaobao.com/realtime/china/story20190413-948394)

- 德国之声：[996.ICU”——码农活命站起来](https://p.dw.com/p/3GSN5)

- FT中文网：[996工作制与中国科技企业的国际化](http://www.ftchinese.com/story/001082216)
- FT中文网：[从“马云三谈996”窥视中国企业家的内心世界](http://www.ftchinese.com/story/001082356?full=y)

## 英文媒体

### 香港媒体

- 南华早报：[‘Developers’ lives matter’ – Chinese software engineers use GitHub to protest against the country’s 996 work schedule](https://www.scmp.com/tech/start-ups/article/3003691/developers-lives-matter-chinese-software-engineers-use-github)
- 南华早报：[Quantity or quality? China’s ‘996’ work culture comes under scrutiny](https://www.scmp.com/tech/start-ups/article/3005947/quantity-or-quality-chinas-996-work-culture-comes-under-scrutiny)

### 非中国媒体

- 《连线》杂志：[How GitHub is helping overworked chinese programmers](https://www.wired.com/story/how-github-helping-overworked-chinese-programmers/)

- Vice：[Chinese Workers Are Trying to Bake Fair Labor Practices Into Software](https://motherboard.vice.com/en_us/article/mbz84n/chinese-workers-are-trying-to-bake-fair-labor-practices-into-software)

- RADII Media：[GitHub Protest Over Chinese Tech Companies' "996" Culture Goes Viral](https://radiichina.com/github-protest-chinese-tech-996/)

- Abacus：[Follow China’s “996” work hours and you’ll end up in an ICU, says Chinese developer](https://www.abacusnews.com/digital-life/follow-chinas-996-work-hours-and-youll-end-icu-says-chinese-developer/article/3003702)

- Abacus：[Chinese browsers block protest against China’s 996 overtime work culture](https://www.abacusnews.com/digital-life/chinese-browsers-block-protest-against-chinas-996-overtime-work-culture/article/3004543)

- Abacus：[Experience the damaging reality of China’s 996 work culture in a new game](https://www.abacusnews.com/games/experience-damaging-reality-chinas-996-work-culture-new-game/article/3077591)

- The Irish Times：[China tech worker protest against long working hours goes viral](https://www.irishtimes.com/business/technology/china-tech-worker-protest-against-long-working-hours-goes-viral-1.3848463)

- The Verge：[Chinese developers use GitHub to protest long work hours](https://www.theverge.com/2019/4/2/18291035/chinese-developers-github-protest-long-work-hours)

- The Verge：[Tencent and Xiaomi may be censoring a GitHub page for airing worker grievances](https://www.theverge.com/2019/4/3/18294030/tencent-xiaomi-china-censorship-browser-block-github-page-worker-grievances)

- The Verge: [Microsoft workers pressure company to stand by embattled Chinese GitHub repo](https://www.theverge.com/2019/4/22/18511088/microsoft-github-tech-censorship-996-repository-china)

- 金融时报：[China tech worker protest against long working hours goes viral](https://archive.is/IZqTj)

- Reuters：[Rare overtime protest by China tech workers goes viral](https://www.reuters.com/article/us-china-tech-labour/rare-overtime-protest-by-china-tech-workers-goes-viral-idUSKCN1RH12B)

## 韩文媒体

- 한경닷컴：["잠도, 섹스도, 삶도 없다"…'996룰'에 반기든 中 스타트업 직원들](https://www.hankyung.com/article/201904053785i)

## 法文媒体

- ZDNet：[996.ICU : Sur Github, les développeurs chinois donnent de la voix](https://www.zdnet.fr/actualites/996icu-sur-github-les-developpeurs-chinois-donnent-de-la-voix-39882985.htm)

## 日文媒体

- HuffPost：[謎のワード「996.ICU」が話題に　残業に苦しむIT社員たちが、過酷な労働実態を相次ぎ告発](https://www.huffingtonpost.jp/entry/996-icu-china_jp_5cad6335e4b01bf960076f52)

- Reuters：[アングル：中国テク業界の過酷な「996」勤務、異例の抗議拡大](https://jp.reuters.com/article/china-overwork-protest-idJPKCN1RK0KV)

- 東方新報：[中国で「996勤務」とは、プログラマーの勤務実態](https://www.afpbb.com/articles/-/3221092)

- 東方新報：[プログラマーの過酷な勤務「996」問題に、中国EC二大巨頭の反応は](https://www.afpbb.com/articles/-/3221206)